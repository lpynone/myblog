---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description: Generic description
categories: []
tags: []
toc: true
math: false
draft: false
---
Generic summary
<!--more-->